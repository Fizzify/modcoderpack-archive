#!/bin/bash
./runtime/recompile.py "$@"
