#!/bin/bash
python runtime/cleanup.py "$@"
